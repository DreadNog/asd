package com.example.naujestest.models;

import java.util.Objects;

public class ForcastModel {
    public String dateTime;
    public Double temperature;
    public String hash;

    public ForcastModel(String dateTime, Double temperature) {
        this.dateTime = dateTime;
        this.temperature = temperature;
        this.hash = String.valueOf(Objects.hash(dateTime, temperature));
    }
}

/*
package com.example.naujestest.models;

public class ForcastModel {
    public String dateTime;
    public Double temperature;
    public ForcastModel(String dateTime, Double temperature){
        this.dateTime = dateTime;
        this.temperature = temperature;
    }
}

*/
