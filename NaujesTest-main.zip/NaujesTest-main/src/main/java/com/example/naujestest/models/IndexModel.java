package com.example.naujestest.models;

import java.util.ArrayList;

public class IndexModel {
    public String city;
    public ArrayList<ForcastModel> forecasts;
}