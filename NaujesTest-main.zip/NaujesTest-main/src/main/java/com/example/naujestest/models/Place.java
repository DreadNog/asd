package com.example.naujestest.models;

public class Place{
    public String code;
    public String name;
    public String administrativeDivision;
    public String country;
    public String countryCode;
    public Coordinates coordinates;
}