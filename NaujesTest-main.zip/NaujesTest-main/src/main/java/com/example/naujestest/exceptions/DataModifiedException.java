package com.example.naujestest.exceptions;

public class DataModifiedException extends RuntimeException {
    public DataModifiedException(String message) {
        super(message);
    }
}