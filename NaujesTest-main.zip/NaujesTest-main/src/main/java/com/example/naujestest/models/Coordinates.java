package com.example.naujestest.models;


public class Coordinates{
    public double latitude;
    public double longitude;
}