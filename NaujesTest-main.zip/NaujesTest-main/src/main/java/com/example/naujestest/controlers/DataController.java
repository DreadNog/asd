package com.example.naujestest.controlers;

import com.example.naujestest.models.ForcastModel;
import com.example.naujestest.exceptions.DataModifiedException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
public class DataController {
    @PostMapping("/saveData")
    public void saveData(@RequestBody ForcastModel forcastModel) {
        String hash = String.valueOf(Objects.hash(forcastModel.dateTime, forcastModel.temperature));
        if (!hash.equals(forcastModel.hash)) {
            throw new DataModifiedException("Data was modified in the front-end");
        }
        System.out.println("recieved data: "+ forcastModel);
    }
}







/*
package com.example.naujestest.controlers;

import com.example.naujestest.models.ForcastModel;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
public class DataController {
    @PostMapping("/saveData")
    public void saveData(@RequestBody ForcastModel forcastModel) {
        String hash = String.valueOf(Objects.hash(forcastModel.dateTime, forcastModel.temperature));
        if (!hash.equals(forcastModel.hash)) {
            throw new RuntimeException("Data was modified in the front-end");
        }
        System.out.println("recieved data: "+ forcastModel);
    }
}

*/






/*
package com.example.naujestest.controlers;

import com.example.naujestest.models.ForcastModel;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataController {
    @PostMapping("/saveData")
    public void saveData(@RequestBody ForcastModel forcastModel) {
        System.out.println("recieved data: "+ forcastModel);
    }
}
*/