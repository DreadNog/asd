package com.example.naujestest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaujesTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
